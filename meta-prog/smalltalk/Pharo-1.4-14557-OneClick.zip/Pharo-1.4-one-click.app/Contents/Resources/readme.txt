1. Create a 512x512 png with transparency of the icon.
2. Convert the icon using http://iconverticons.com/ to icns (mac) and ico (windows).