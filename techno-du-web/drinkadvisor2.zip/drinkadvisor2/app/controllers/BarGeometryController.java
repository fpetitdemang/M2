package controllers;

import java.io.IOException;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import models.OSMNode;
import models.Entry;
import play.Routes;
import play.data.Form;
import play.mvc.Controller;
import play.mvc.Result;

public class BarGeometryController extends Controller{

	static Form<Entry> entryForm = Form.form(Entry.class);

	 public static Result listBars() throws IOException, SAXException, ParserConfigurationException
	    {
		 	
	    	List<OSMNode> bars ;
	    	bars = OSMNode.allBars();
	    	if(request().accepts("text/html"))
	    		return ok(views.html.bars.render(bars, "Bars Montpellier", "Trinkadvisor"));
//	    	else if(request().accepts("application/json"))
//	    		return ok(Json.toJson(tweets));
//	    	else if (request().accepts("application/rdf+xml"))
//	    		return ok("this will be RDF XML");
	    	return badRequest();
	    }
	 
	public static Result addUser(String name, String firstname){
		
		Entry test = new Entry(name,firstname);
        test.save();
        System.out.println("saved in bargeometry");
        return redirect(routes.BarGeometryController.listBars());
		
	}
	
	 public static Result javascriptRoutes() {
	      response().setContentType("text/javascript");
	      return ok(
	        Routes.javascriptRouter("jsRoutes",
	          // Routes
	        
	          controllers.routes.javascript.BarGeometryController.addUser()
	        )
	      );
	    }
	
}
