package controllers;

import java.util.ArrayList;
import java.util.List;

import com.hp.hpl.jena.query.QuerySolution;


import models.Beer;
import play.*;
import play.data.Form;
import play.libs.Json;
import play.mvc.*;

import views.html.*;

public class BeerInfo extends Controller {

	static Form<Beer> beerform = Form.form(Beer.class);
	 public static Result listBeers(String name)
	    {
	    	List<QuerySolution>  bars;
	    	bars = Beer.all(name);
	    	List<Beer> beers = new ArrayList<Beer>();
	    	
	    	for(QuerySolution q: bars){
	    		Beer b = new Beer();
	    		b.location=q.get("location").toString();
	    		b.nom=q.get("beer").toString();
	    		b.abstractt=q.get("abstract").toString();
	    		b.country = q.get("country").toString();
	    		beers.add(b);
	    	}
	    	
	    	if(request().accepts("text/html"))
	    		return ok(views.html.infobeers.render(beers, "Infos sur les bières", beerform, "hello Gilles"));
	    	else if(request().accepts("application/json"))
	    		return ok(Json.toJson(bars));
	    	else if (request().accepts("application/rdf+xml"))
	    		return ok("this will be RDF XML");
	    	
	    	return badRequest();
	    	
	    }
	
	 public static Result submitBeers()
	    {
	    	Beer beer = beerform.bindFromRequest().get();
	    	String test = beerform.bindFromRequest().get().nom;
	    	beer.fillList(test);
	    	return redirect(routes.BeerInfo.listBeers(test));
	    }
	
	 
	 

}
