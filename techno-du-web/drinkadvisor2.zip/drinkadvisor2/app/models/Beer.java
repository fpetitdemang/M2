package models;

import java.util.List;
import java.util.Map;

import javax.persistence.Id;

import com.hp.hpl.jena.query.QuerySolution;

import play.db.ebean.Model;
import play.db.ebean.Model.Finder;

public class Beer extends Model{
	
	@Id
	public String id ;
	public String nom ;
	public String location;
	public String abstractt;
	public String country;
	public static List<QuerySolution> allbeers;
	//public static Finder<Long, Beer> find = new Finder<Long, Beer>(Long.class, Beer.class);
	
	public void fillList(String name){
		allbeers = Sparql.retourlist(name);
	}
	
	public static List<QuerySolution> all(String name)
	{
		allbeers = Sparql.retourlist(name);
		return allbeers;
	}

}
