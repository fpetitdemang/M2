package models;

import javax.persistence.*;

import play.db.ebean.*;
import play.data.validation.*;

@Entity
public class Entry extends Model {

	public Entry(String name, String firstname) {
		this.name=name;
		this.firstname=firstname;
		// TODO Auto-generated constructor stub
	}

	@Id
	public long userID;
	
	public String name;
	
	@Constraints.Required
	public String firstname;
	
	public static Model.Finder<Long, Entry> find = new Model.Finder
			<Long, Entry>(Long.class,Entry.class);
	
}
