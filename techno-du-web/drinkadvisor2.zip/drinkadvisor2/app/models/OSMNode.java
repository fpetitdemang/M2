package models;


import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.persistence.Id;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import play.db.ebean.Model;

public class OSMNode  extends Model{


	@Id
	public String id ;
	public String lon ;
	public String lat;
	private Map<String, String> tags;
	public String name;
	private String version;

	public OSMNode(String id2, String latitude, String longitude,
			String version2, String name) {
		this.id=id2;
		this.lat = latitude;
		this.lon = longitude;
		this.version = version2;
		this.name = name;

		// TODO Auto-generated constructor stub
	}


	private static final long serialVersionUID = 1L;

	public static Finder<Long, OSMNode> barfinder = new Finder<Long, OSMNode>(Long.class, OSMNode.class);

	public static List<OSMNode> allBars() throws IOException, SAXException, ParserConfigurationException
	{
		List<OSMNode> osmNodesInVicinity = ConnectOSMApi.getOSMNodesInVicinity(49, 8.3, 0.005);
		//		for (OSMNode osmNode : osmNodesInVicinity) {
		//			System.out.println(osmNode.getTags());
		//			System.out.println("Logitude : "+osmNode.getLon());
		//			System.out.println("Latitude : "+osmNode.getLat());
		//		}
		return osmNodesInVicinity;
	}



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLon() {
		return lon;
	}

	public void setLon(String lon) {
		this.lon = lon;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public Map<String, String> getTags() {
		return tags;
	}



}