package models;

import java.util.List;

import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.query.ResultSetFormatter;

public class Sparql {
	String location = null;
	String beeruri = null;
	public static  List<QuerySolution> retourlist(String name) {
		 List<QuerySolution> res;
		String querystring=
				"PREFIX owl: <http://www.w3.org/2002/07/owl#>" +
						"PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>" +
						"PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>" +
						"PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>" +
						"PREFIX foaf: <http://xmlns.com/foaf/0.1/>" +
						"PREFIX dc: <http://purl.org/dc/elements/1.1/>" +
						"PREFIX dbpedia2: <http://dbpedia.org/property/>" +
						"PREFIX dbpedia: <http://dbpedia.org/>" +
						"PREFIX skos: <http://www.w3.org/2004/02/skos/core#>" +
						"PREFIX : <http://dbpedia.org/resource/>" +
						"PREFIX dbo: <http://dbpedia.org/ontology/>"+
						"SELECT DISTINCT ?location ?beer ?abstract ?country  where {"+
						"?beer dbo:product :Beer ."+
						"?beer rdfs:label ?label "+
						"FILTER regex(?label, \"^"+name+"\") ."+
						" ?beer dbo:locationCity ?location ."+
					    " ?beer dbo:abstract ?abstract ."+
						" ?beer dbo:locationCountry ?country"+
						"}"+
						"ORDER BY ?name";
		System.out.println(querystring);
		String service = "http://dbpedia.org/sparql";
		QueryExecution qe = QueryExecutionFactory.sparqlService(service, querystring);

		try {

			 ResultSet rs = qe.execSelect() ;
	            // ResultSetFormatter.out(System.out, rs);
	            res = ResultSetFormatter.toList(rs);    
	             for(QuerySolution q : res){
	            	
	            	String location = q.get("location").toString();
	            	String beer = q.get("beer").toString();
	            	System.out.println(location);
	            	System.out.println(beer);
	             }
	             


		}
		finally {
			qe.close();
		}

		return res;



	}
}

