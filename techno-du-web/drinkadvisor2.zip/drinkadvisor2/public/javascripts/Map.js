var map;
var vectorLayerJSON;
var style_green;
var epsg4326;
var epsg900913;
var options;
function init() {
	
	
	
	    map = new OpenLayers.Map({
	        div: "map",
	        allOverlays: true
	    });	    
	    map.addControl(new OpenLayers.Control.MousePosition({displayProjection: epsg4326})); //affichage localisation de la souris
    
  

    var osm = new OpenLayers.Layer.OSM();
    var gmap = new OpenLayers.Layer.Google("Google Streets", {visibility: true});
  
    // note that first layer must be visible
    map.addLayers([osm, gmap]);

//    var point =  new OpenLayers.Geometry.Point(3.4, 43.3).transform(epsg4326, epsg900913);
//
//	var pointFeature = new OpenLayers.Feature.Vector(point, style_green);
//	vectorLayerJSON.addFeatures([pointFeature]);
    map.addControl(new OpenLayers.Control.LayerSwitcher());
	map.zoomToExtent(vectorLayerJSON.getDataExtent());
	drawmap();
}

function initbaselayer(){
	

    vectorLayerJSON = new OpenLayers.Layer.Vector("JSON Vector", {
    	isBaseLayer : true

        });
}

function createpoint(atr, pointf){
	
	var pointFeature = new OpenLayers.Feature.Vector(pointf, atr, style_green);
	vectorLayerJSON.addFeatures([pointFeature]);
	
}

function drawmap(){
	map.addLayer(vectorLayerJSON);
	map.zoomToExtent(vectorLayerJSON.getDataExtent());
	
}


function initvar(){
	  style_green = {
	            strokeColor: "#00FF00",
	            strokeWidth: 3,
	            pointRadius: 12,
	            pointerEvents: "visiblePainted",
	            externalGraphic: "assets/images/beer.png"
	        };
	 epsg4326 = new OpenLayers.Projection('EPSG:4326');
	    epsg900913 = new OpenLayers.Projection('EPSG:900913');
	    
	    
	    options  = {
				controls: [],
				hover: false,
				projection: epsg900913,
				displayProjection: epsg4326,
				units : "m",
				extent: [-5, 35, 15, 55],
				maxResolution: 156543.0339,
				maxExtent: new OpenLayers.Bounds(-20037508, -20037508, 20037508, 20037508.34)
			    };
}
