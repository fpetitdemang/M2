import sbt._

object LicenseHelper {

  val licenseReport = TaskKey[String]("license-report")


}