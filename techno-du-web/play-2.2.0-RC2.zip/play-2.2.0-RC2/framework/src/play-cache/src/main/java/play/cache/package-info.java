/**
 * Provides the Cache API.
 */
package play.cache;
