package play.api

/**
 * Contains the Cache access API.
 */
package object cache