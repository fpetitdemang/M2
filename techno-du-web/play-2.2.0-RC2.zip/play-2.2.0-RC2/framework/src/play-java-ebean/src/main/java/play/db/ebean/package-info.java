/**
 * Provides Ebean ORM integration.
 *
 * <p><a href="http://www.avaje.org/ebean/documentation.html">http://www.avaje.org/ebean/documentation.html</a></p>
 */
package play.db.ebean;