/**
 * Provides JPA ORM integration.
 */
package play.db.jpa;