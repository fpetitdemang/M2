/**
 * Provides the formatting API used by <code>Form</code> classes.
 */
package play.data.format;