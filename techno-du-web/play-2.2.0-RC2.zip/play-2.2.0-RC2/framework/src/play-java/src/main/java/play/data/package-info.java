/**
 * Provides data manipulation helpers, mainly for HTTP form handling.
 */
package play.data;