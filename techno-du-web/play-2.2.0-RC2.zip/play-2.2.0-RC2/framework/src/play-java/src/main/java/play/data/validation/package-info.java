/**
 * Provides the JSR 303 validation constraints.
 */
package play.data.validation;