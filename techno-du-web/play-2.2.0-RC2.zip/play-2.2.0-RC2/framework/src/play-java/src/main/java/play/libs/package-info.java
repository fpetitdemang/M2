/**
 * Provides various APIs that are useful for developing web applications.
 */
package play.libs;