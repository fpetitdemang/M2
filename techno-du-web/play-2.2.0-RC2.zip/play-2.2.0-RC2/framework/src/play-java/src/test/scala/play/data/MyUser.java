package play.data;

import play.libs.F.Option;

public class MyUser {
    public String email;
    public String password;
    public String extraField1;
    public String extraField2;
    public String extraField3;
}
