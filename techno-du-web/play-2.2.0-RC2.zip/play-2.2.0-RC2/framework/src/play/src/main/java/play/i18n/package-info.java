/**
 * Provides the i18n API.
 */
package play.i18n;
