package play.mvc;

/**
 * Generic type representing content to be sent over an HTTP response.
 */
public interface Content extends play.api.mvc.Content {
    
}