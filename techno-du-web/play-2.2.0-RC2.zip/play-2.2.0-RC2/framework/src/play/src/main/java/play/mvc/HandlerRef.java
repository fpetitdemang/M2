package play.mvc;

/**
 * Reference to an Handler.
 */
public interface HandlerRef {
    
}