/**
 * Provides the Play framework's publicly accessible Java API.
 *
 * <h3>Play</h3>
 * <a href="http://www.playframework.com">http://www.playframework.com</a>
 */
package play;
