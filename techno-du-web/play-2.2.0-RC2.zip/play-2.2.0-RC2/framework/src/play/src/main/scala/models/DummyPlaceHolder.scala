package models

/*
 * Empty placeholder object to make sure templates keep compiling (due to
 * imports in template files), even if projects don't have any models.
 */
object DummyPlaceHolder