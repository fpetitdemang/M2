package play.api.libs

/**
 * OAuth integration helpers.
 */
package object oauth