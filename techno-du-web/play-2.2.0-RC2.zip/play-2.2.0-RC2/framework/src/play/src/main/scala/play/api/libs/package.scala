package play.api

/**
 * Contains various APIs that are useful while developing web applications.
 */
package object libs