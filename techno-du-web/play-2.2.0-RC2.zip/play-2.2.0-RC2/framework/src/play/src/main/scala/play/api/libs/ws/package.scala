package play.api.libs

/**
 * Asynchronous API to to query web services, as an http client.
 */
package object ws