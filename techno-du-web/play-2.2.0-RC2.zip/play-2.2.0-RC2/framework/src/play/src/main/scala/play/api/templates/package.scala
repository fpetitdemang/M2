package play.api

/**
 * Contains Template adapters for typical Play applications.
 */
package object templates