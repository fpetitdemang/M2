package views.html

/**
 * Contains default error, 404, forbidden, etc. pages.
 */
package object defaultpages