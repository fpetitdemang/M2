package play.api.libs.openid

 trait RichUrl[A] {
    def hostAndPath: String
  }  