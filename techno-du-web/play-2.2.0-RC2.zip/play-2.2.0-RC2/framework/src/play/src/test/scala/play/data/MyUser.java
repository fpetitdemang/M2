package play.data;

public class MyUser {
    public String email;
    public String password;
    public String extraField1;
    public String extraField2;
    public String extraField3;
}
